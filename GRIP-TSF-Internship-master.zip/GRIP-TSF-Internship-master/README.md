# Banking-system-
I have created virtual money transfer - basic banking system A web application used to transfer virtual money between multiple users and also record the banking transactions. The website has the following specs :-

A dummy data for upto 10 customers.
Customers table withbasic fields such as name, email, current balance etc.
Transfer History which records all the transactions.
No Login Page, No user creation. Only Transfer of Money. Flow : Home Page > View all customers > Select and View one customer > Transfer Money > Select customer to transfer to > View all Customers.
